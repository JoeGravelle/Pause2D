*****************************
*			    *
*PPP    A    U U   SSS   EEE*
*P P   A A   U U   S	 E  *
*PPP   AAA   U U   SSS	 EE *
*P     A A   U U     S	 E  *
*P     A A   UUU   SSS	 EEE*
*			    *
*****************************
Facedesk Software


Controls:

W - Jump
A - Move Left
D - Move Right
Escape - Pause Time

Use your mouse to drag the blocks - while paused- to get out of the maze!


(If there are any problems contact Joseph Gravelle jogravelle@gmail.com)

